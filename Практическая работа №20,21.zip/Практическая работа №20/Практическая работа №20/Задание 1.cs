﻿using System;

namespace SumCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите числа (вводите 0 для завершения):");
            int sum = 0;
            int number;

            while (true)
            {
                bool isValid = Int32.TryParse(Console.ReadLine(), out number);

                if (isValid)
                {
                    if (number == 0)
                    {
                        break;
                    }

                    sum += number;
                }
                else
                {
                    Console.WriteLine("Ошибка: Введите корректное целое число.");
                }
            }

            Console.WriteLine($"Сумма введённых чисел: {sum}");
        }
    }
}