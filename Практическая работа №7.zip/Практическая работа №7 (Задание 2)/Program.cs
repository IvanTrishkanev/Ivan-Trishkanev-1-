﻿using System;

class Program
{
    static void Main()
    {
        string text = "Я скоро поеду на научную конференцию в Курск";
        int index = text.IndexOf("Курск");
        Console.WriteLine($"Индекс слова 'Курск': {index}");
        string modifiedText = text.Replace(" в Курск", "");
        modifiedText = modifiedText.Replace("научную конференцию", "соревнование");
        modifiedText = modifiedText.ToUpper();
        Console.WriteLine(modifiedText);
    }
}