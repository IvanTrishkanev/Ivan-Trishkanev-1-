﻿using System;

namespace Практическая_работа__13
{
    class Program1
    {
        public static void Main(string[] args)
        {
            int[] numbers = { 15, 25, 30, 45, 50, 55, 22, 35, 19, 40 };

            Console.WriteLine("Элементы массива, которые больше 20 и меньше 50:");
            foreach (int number in numbers)
            {
                if (number > 20 && number < 50)
                {
                    Console.WriteLine(number);
                }
            }
        }
    }
}