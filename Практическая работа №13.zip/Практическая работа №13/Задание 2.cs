﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическая_работа__13
{
    internal class Задание_2
    {
        public static void Main(string[] args)
        {
            int sum = 0;

            for (int i = 1; i < 20; i += 2)
            {
                sum += i;
            }
            Console.WriteLine("Сумма первых 10 нечетных чисел = {0}", sum);
        }
    }
}
