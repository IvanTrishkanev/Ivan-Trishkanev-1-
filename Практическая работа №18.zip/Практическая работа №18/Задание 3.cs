﻿using System;
using System.IO;

class Program3
{
    static void Main3(string[] args)
    {
        string path = "C:\\Users\\beybl\\source\\repos\\Практическая работа №17\\your-file.txt";
        int maxLength = 0;

        using (StreamReader reader = new StreamReader(path))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                if (line.Length > maxLength)
                {
                    maxLength = line.Length;
                }
            }
        }
        Console.WriteLine($"Длина самой длинной строки: {maxLength} символов.");
    }
}
