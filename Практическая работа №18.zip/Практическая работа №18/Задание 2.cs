﻿using System;
using System.IO;

class Program2
{
    internal class Задание_2
    {
    static void Main2(string[] args)
    {
        string[] colors = { "red", "green", "black", "white", "blue" };
        string path = "C:\\Users\\beybl\\source\\repos\\Практическая работа №17\\colors.txt";

        using (StreamWriter writer = new StreamWriter(path))
        {
            foreach (string color in colors)
            {
                writer.WriteLine(color);
            }
        }
        Console.WriteLine("Файл colors.txt успешно создан!");
    }
  }
}