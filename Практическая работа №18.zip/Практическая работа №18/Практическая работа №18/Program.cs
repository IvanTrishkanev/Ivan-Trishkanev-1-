﻿using System;

namespace RandomNumberGenerator
{
    class Program1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите нижнюю границу диапазона:");
            int lowerBound = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите верхнюю границу диапазона:");
            int upperBound = Convert.ToInt32(Console.ReadLine());

            if (upperBound <= lowerBound)
            {
                Console.WriteLine("Ошибка: верхняя граница должна быть больше нижней.");
                return;
            }

            Random random = new Random();
            Console.WriteLine("Случайные числа в диапазоне от {0} до {1}:", lowerBound, upperBound);

            for (int i = 0; i < 10; i++)
            {
                int randomNumber = random.Next(lowerBound, upperBound + 1);
                Console.WriteLine(randomNumber);
            }

            Console.WriteLine("Нажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}