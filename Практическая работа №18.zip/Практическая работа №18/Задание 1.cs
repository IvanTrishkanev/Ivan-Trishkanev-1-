﻿using System;
using System.IO;

class Program1
{
    static void Main(string[] args)
    {
        string path = "C:\\Users\\beybl\\source\\repos\\Практическая работа №17\\numbers.txt";
        using (StreamWriter writer = new StreamWriter(path))
        {
            for (int i = 1; i <= 500; i++)
            {
                writer.Write(i);
                if (i < 500)
                    writer.Write(", ");
            }
        }
        Console.WriteLine("Файл numbers.txt успешно создан!");
    }
}