﻿using System;

namespace MinNumberFinder
{
    class Program1
    {
        static void Main(string[] args)
        {
            int number;
            int min = int.MaxValue;
            bool found = false;

            do
            {
                Console.Write("Введите целое число (0 для завершения): ");
                number = int.Parse(Console.ReadLine());
                if (number != 0)
                {
                    if (number < min)
                    {
                        min = number;
                    }
                    found = true;
                }

            } while (number != 0);

            if (found)
            {
                Console.WriteLine("Минимальное число: " + min);
            }
            else
            {
                Console.WriteLine("Последовательность пуста.");
            }
        }
    }
}