﻿using static System.Console;

namespace ChessBoard
{
    class Program5
    {
        internal class Задание_4
        {


            public static void Main4(string[] args)
            {
                int rows = 8;
                int columns = 8;
                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < columns; j++)
                    {
                        char symbol = (i % 2 == 0) ? (j % 2 == 0 ? 'X' : 'O') : (j % 2 == 0 ? 'O' : 'X');
                        Write(symbol);
                    }
                    WriteLine();
                }
            }
        }
    }
}