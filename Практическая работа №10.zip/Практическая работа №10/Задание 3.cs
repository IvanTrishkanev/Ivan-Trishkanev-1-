﻿using static System.Console;
using static System.Math;

namespace FunctionCalculation
{
    class Program3
    {
        internal class Задание_3
        {

            public static void Main2(string[] args)
            {

            double x;
            double expression;

            for (int i = 1; i <= 3; i++)
            {
                Write("Введите значение x для {0}: ", i);
                x = Convert.ToDouble(ReadLine());
                expression = x - 3;
                double y = 4 * Pow(expression, 6) - 7 * Pow(expression, 3) + 2;

                WriteLine("Значение функции y = 4(x - 3)^6 - 7(x - 3)^3 + 2 для x = {0} равно: {1}", x, y);
            }
        }
    }
  }
}