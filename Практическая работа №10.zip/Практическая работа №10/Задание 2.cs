﻿using System;

namespace FindMaximum
{
    class Program2
    {
        internal class Задание_2
        {

        public static void Main1(string[]args)
        {
            int number;
            int maxNumber = int.MinValue;
            int position = 0;
            int currentPosition = 0;

                do
                {
                    Console.Write("Введите число (для завершения введите 0): ");
                    number = Convert.ToInt32(Console.ReadLine());

                    if (number != 0)
                    {
                        currentPosition++;

                        if (number > maxNumber)
                        {
                            maxNumber = number;
                            position = currentPosition;
                        }
                    }
                } while (number != 0);

                if (position > 0)
            {
                Console.WriteLine("Максимальное число: {0}, его порядковый номер в последовательности: {1}", maxNumber, position);
            }
            else
            {
                Console.WriteLine("Не было введено ни одного числа.");
            }
        }
    }
  }
}