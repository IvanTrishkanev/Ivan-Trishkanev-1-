﻿using static System.Console;

namespace ChessBoardColor
{
    class Program4
    {
        internal class Задание_4
        {

            public static void Main3(string[] args)
            {
                int x, y;
                Write("Введите координаты x (1-8): ");
                x = Convert.ToInt32(ReadLine());
                Write("Введите координаты y (1-8): ");
                y = Convert.ToInt32(ReadLine());
                if (x < 1 || x > 8 || y < 1 || y > 8)
                {
                    WriteLine("Координаты должны быть в диапазоне от 1 до 8.");
                    return;
                }

                string color = ((x + y) % 2 == 0) ? "черный" : "белый";

                WriteLine("Квадрат с координатами ({0}, {1}) - {2}", x, y, color);
            }
        }
    }
}