﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическая_работа__6
{
    internal class Задание_3
    {
        class Program3
        {
            static void Main3()
            {
                Console.WriteLine("Курский государственный политехнический колледж");
                Console.WriteLine("Контактная информация");
                Console.WriteLine("Контактные телефоны: +7 (4712) 37-02-19");
                Console.WriteLine("Контактный факс: +7 (4712) 37-02-19");
            }
        }
    }
}
