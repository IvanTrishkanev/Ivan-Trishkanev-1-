﻿using System;

namespace OperationsSelector
{
    class Program6
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите номер операции:");
            Console.WriteLine("1. Сложение");
            Console.WriteLine("2. Вычитание");
            Console.WriteLine("3. Умножение");
            int operationNumber;
            if (int.TryParse(Console.ReadLine(), out operationNumber))
            {
                string operationName;
                switch (operationNumber)
                {
                    case 1:
                        operationName = "Сложение";
                        break;
                    case 2:
                        operationName = "Вычитание";
                        break;
                    case 3:
                        operationName = "Умножение";
                        break;
                    default:
                        operationName = "Операция неопределена";
                        break;
                }
                Console.WriteLine($"Выбрана операция: {operationName}");
            }
            else
            {
                Console.WriteLine("Некорректный ввод. Пожалуйста, введите номер операции.");
            }
            Console.ReadKey();
        }
    }
}