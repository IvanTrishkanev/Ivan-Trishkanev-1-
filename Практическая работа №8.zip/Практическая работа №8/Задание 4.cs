﻿using System;

namespace BankInterestCalculator
{
    class Program4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите сумму вклада: ");
            double depositAmount;
            if (double.TryParse(Console.ReadLine(), out depositAmount))
            {
                double interestRate;
                double finalAmount;

                if (depositAmount < 100)
                {
                    interestRate = 0.05;
                }
                else if (depositAmount >= 100 && depositAmount <= 200)
                {
                    interestRate = 0.07;
                }
                else
                {
                    interestRate = 0.10;
                }

                finalAmount = depositAmount + (depositAmount * interestRate);

                Console.WriteLine($"Сумма вклада с начисленными процентами: {finalAmount:F2}");
            }
            else
            {
                Console.WriteLine("Введено некорректное значение. Пожалуйста, введите числовое значение.");
            }
            Console.ReadKey();
        }
    }
}