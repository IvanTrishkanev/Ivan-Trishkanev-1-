﻿using System;

namespace BankInterestCalculatorWithBonus
{
    class Program5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите сумму вклада: ");
            double depositAmount;

            if (double.TryParse(Console.ReadLine(), out depositAmount))
            {
                double interestRate;
                double finalAmount;

                if (depositAmount < 100)
                {
                    interestRate = 0.05;
                }
                else if (depositAmount >= 100 && depositAmount <= 200)
                {
                    interestRate = 0.07;
                }
                else
                {
                    interestRate = 0.10;
                }
                finalAmount = depositAmount + (depositAmount * interestRate);
                finalAmount += 15;
                Console.WriteLine($"Сумма вклада с начисленными процентами и бонусами: {finalAmount:F2}");
            }
            else
            {
                Console.WriteLine("Ошибка: введено некорректное значение. Пожалуйста, введите число.");
            }

            Console.ReadKey();
        }
    }
}