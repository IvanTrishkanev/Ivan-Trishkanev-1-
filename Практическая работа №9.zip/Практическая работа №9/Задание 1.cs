﻿using System;

class Program1
{
    internal class Задание_1
    {
        static void Main(string[] args)
        {
            Console.Write("Введите сумму вклада (например, 1000): ");
            decimal суммаВклада = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Введите количество месяцев: ");
            int количествоМесяцев = Convert.ToInt32(Console.ReadLine());

            decimal процент = 0.07m;
            decimal конечнаяСумма = суммаВклада;

            for (int i = 1; i <= количествоМесяцев; i++)
            {
                конечнаяСумма += конечнаяСумма * процент;
            }
            Console.WriteLine($"Конечная сумма вклада через {количествоМесяцев} месяцев составит: {конечнаяСумма:C}");
        }
    }
}