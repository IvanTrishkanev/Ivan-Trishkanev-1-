﻿using System;

class Program4
{
    internal class Задание_4
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("Введите первое число (от 0 до 10): ");
                decimal первоеЧисло = Convert.ToDecimal(Console.ReadLine());

                Console.Write("Введите второе число (от 0 до 10): ");
                decimal второеЧисло = Convert.ToDecimal(Console.ReadLine());

                if (первоеЧисло < 0 || первоеЧисло > 10 || второеЧисло < 0 || второеЧисло > 10)
                {
                    Console.WriteLine("Оба числа должны быть в диапазоне от 0 до 10. Попробуйте еще раз.");
                    continue;
                }
                decimal результат = первоеЧисло * второеЧисло;
                Console.WriteLine($"Результат умножения {первоеЧисло} * {второеЧисло} = {результат}");
                break;
            }
        }
    }
}
