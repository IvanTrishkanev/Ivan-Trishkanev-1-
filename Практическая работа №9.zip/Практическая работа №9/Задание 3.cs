﻿using System;

class Program3
{
    internal class Задание_3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Таблица умножения");
            Console.WriteLine("------------------");

            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    int результат = i * j;
                    Console.Write($"{i} * {j} = {результат}\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine("------------------");
        }
    }
}
