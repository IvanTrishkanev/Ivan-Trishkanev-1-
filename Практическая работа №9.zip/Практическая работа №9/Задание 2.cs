﻿using System;

class Program
{
    internal class Задание_2
    {
        static void Main(string[] args)
        {
            Console.Write("Введите сумму вклада (например, 1000): ");
            decimal суммаВклада = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Введите количество месяцев: ");
            int количествоМесяцев = Convert.ToInt32(Console.ReadLine());
            decimal процент = 0.07m;
            decimal конечнаяСумма = суммаВклада;

            int месяц = 0;

            while (месяц < количествоМесяцев)
            {
                конечнаяСумма += конечнаяСумма * процент;
                месяц++;
            }
            Console.WriteLine($"Конечная сумма вклада через {количествоМесяцев} месяцев составит: {конечнаяСумма:C}");
        }
    }
}
