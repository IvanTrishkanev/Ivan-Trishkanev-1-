﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическая_работа__5
{
    internal class Задание_3
    {
        class Program3
        {
            static void Main3(string[] args)
            {
                double x = 9;
                double firstValue, secondValue, otvet;
                firstValue = Math.Pow(x, 2);
                secondValue = Math.Pow(3, 3) * Math.Sqrt(x);
                otvet = 2 * firstValue - secondValue;
                Console.WriteLine("Ответ = " + otvet);
                Console.ReadKey();
            }
        }
    }
}
