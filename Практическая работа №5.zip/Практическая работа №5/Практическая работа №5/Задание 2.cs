﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическая_работа__5
{
    internal class Задание_2
    {
        class Program2
        {
            static void Main2(string[] args)
            {
                Console.Write("dведите а ");
                double a = double.Parse(Console.ReadLine());
                Console.Write("dведите b ");
                double b = double.Parse(Console.ReadLine());
                double c = Math.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2));
                Console.WriteLine($"c равно {c}");
            }
        }
    }
}

