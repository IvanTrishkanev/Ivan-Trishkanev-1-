﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическая_работа__5
{
    internal class Задание_6
    {
        class Program6
        {
            static void Main6(string[] args)
            {
                double a = 6;
                double b = 10;
                double c = (a / 54 * b + 4.89) / (-7.86 - Math.Sqrt(1024) + Math.Pow(a, 2) / (b * 3.9));
                Console.WriteLine($"c получается {Math.Round(c, 2)}");
            }
        }
    }
}
