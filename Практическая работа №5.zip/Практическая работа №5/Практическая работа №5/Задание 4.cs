﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическая_работа__5
{
    internal class Задание_4
    {
        class Program4
        {
            static void Main4(string[] args)
            {
                double x = 4;
                double otvet;
                otvet = 5 * Math.Pow(x, 2) - 12 * x + 4 / 6 - 15 * x;
                Console.WriteLine($"Ответ={otvet}");
                Console.ReadKey();
            }
        }
    }
}
