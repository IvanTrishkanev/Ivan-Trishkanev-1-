﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практическая_работа__5
{
    internal class Задание_5
    {
        class Program5
        {
            static void Main5(string[] args)
            {
                double x = 2;
                double y = 5;
                double frX = -x;
                double frY = -y;
                double frXY = -x * -y;
                double otvet = frX - frY / (1 + frXY);
                Console.WriteLine($"Ответ {otvet}");
                Console.ReadKey();
            }
        }
    }
}
