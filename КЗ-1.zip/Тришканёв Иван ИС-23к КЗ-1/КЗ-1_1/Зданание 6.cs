﻿using System;

class Program6
{
    static void Main6(string[] args)
    {
        Console.Write("Введите число n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        for (int i = 0; i <= n; i++)
        {
            if (i % 3 == 0 || i % 7 == 0)
            {
                Console.WriteLine(i);
            }
        }
    }
}
