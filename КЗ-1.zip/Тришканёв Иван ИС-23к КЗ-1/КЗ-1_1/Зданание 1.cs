﻿using System;
class Program1
{
    static void Main1()
    {
        for (int i = 0; i <= 10; i++)
        {
            Console.WriteLine(i);
        }
    }
}
