﻿using System;

class Program8
{
    static void Main8(string[] args)
    {
        Console.Write("Введите число n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int sum = 0;
        for (int i = 2; i <= n; i += 2)
        {
            sum += i;
        }
        Console.WriteLine(sum);
    }
}
