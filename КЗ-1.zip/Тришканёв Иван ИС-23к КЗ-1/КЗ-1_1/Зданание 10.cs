﻿using System;

class Program10
{
    static void Main10(string[] args)
    {
        Console.Write("Введите число n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int sum = 0;
        for (int i = 1; i <= n; i++)
        {
            if (i % 3 == 0)
            {
                sum += i;
            }
        }
        Console.WriteLine(sum);
    }
}