﻿using System;

class Program22
{
    static void Main22()
    {
        Console.Write("Введите натуральное число K: ");
        int K = Convert.ToInt32(Console.ReadLine());
        int count = 0;

        for (int i = 1; i <= K; i++)
        {
            if (IsPalindrome(i))
            {
                count++;
            }
        }

        Console.WriteLine(count);
    }

    static bool IsPalindrome(int number)
    {
        string str = number.ToString();
        char[] arr = str.ToCharArray();
        Array.Reverse(arr);
        string reversedStr = new string(arr);
        return str == reversedStr;
    }
}