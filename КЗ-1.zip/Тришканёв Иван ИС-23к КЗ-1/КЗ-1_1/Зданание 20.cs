﻿using System;

class Program20
{
    static void Main20()
    {
        Console.Write("Введите целое число n: ");
        int n = Convert.ToInt32(Console.ReadLine());
        int sum = 0;
        for (int i = 0; i < n; i++)
        {
            int term = 2 * i + 1;
            sum += term;
            Console.WriteLine(sum);
        }
        Console.WriteLine(sum);
    }
}