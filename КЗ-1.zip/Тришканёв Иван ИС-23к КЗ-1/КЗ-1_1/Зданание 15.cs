﻿using System;

class Program15
{
    static void Main15()
    {
        Console.Write("Введите целое число N: ");
        int N = Convert.ToInt32(Console.ReadLine());
        bool isFib = false;
        int previousFib = 1;
        int currentFib = 1;

        while (currentFib <= N)
        {
            if (currentFib == N)
            {
                isFib = true;
                break;
            }
            int nextFib = previousFib + currentFib;
            previousFib = currentFib;
            currentFib = nextFib;
        }
        Console.WriteLine(isFib ? "TRUE" : "FALSE");
    }
}