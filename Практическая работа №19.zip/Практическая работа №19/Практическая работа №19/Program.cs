﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите угол в градусах: ");
        string input = Console.ReadLine();

        if (double.TryParse(input, out double angleInDegrees))
        {
            double angleInRadians = angleInDegrees * (Math.PI / 180.0);

            double sineValue = Math.Sin(angleInRadians);

            Console.WriteLine($"Синус угла {angleInDegrees} градусов равен {sineValue}");
        }
        else
        {
            Console.WriteLine("Ошибка: введено некорректное значение.");
        }
    }
}