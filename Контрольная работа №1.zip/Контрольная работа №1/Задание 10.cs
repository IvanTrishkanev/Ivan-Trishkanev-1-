﻿using System;
using System.Linq;

class Program10
{
    static void Main10()
    {
        string[] firstLine = Console.ReadLine().Split(' ');
        int t = int.Parse(firstLine[0]);
        int v = int.Parse(firstLine[1]);
        string[] secondLine = Console.ReadLine().Split(' ');
        int[] volumes = secondLine.Select(int.Parse).ToArray();
        int totalTrucks = 0;
        for (int i = 0; i < t; i++)
        {
            int dailyVolume = volumes[i];
            if (i == 0)
            {
                if (dailyVolume > 0)
                {
                    totalTrucks += 1;
                }
            }
            int remainingVolume = dailyVolume - (i == 0 ? v / 2 : 0);
            if (remainingVolume > 0)
            {
                totalTrucks += (remainingVolume + v - 1) / v;
            }
        }
        Console.WriteLine(totalTrucks);
    }
}