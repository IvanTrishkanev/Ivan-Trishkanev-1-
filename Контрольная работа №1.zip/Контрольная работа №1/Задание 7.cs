﻿using System;

class Program7
{
    static void Main7()
    {
        int N = int.Parse(Console.ReadLine());
        int oppositeSeatNumber;
        char seatType;

        int seatInCoupe = (N - 1) % 12;

        switch (seatInCoupe)
        {
            case 0:
                oppositeSeatNumber = N + 11;
                seatType = 'W';
                break;
            case 1:
                oppositeSeatNumber = N + 9;
                seatType = 'M';
                break;
            case 2:
                oppositeSeatNumber = N + 7;
                seatType = 'A';
                break;
            case 3:
                oppositeSeatNumber = N + 5;
                seatType = 'A';
                break;
            case 4:
                oppositeSeatNumber = N + 3;
                seatType = 'M';
                break;
            case 5:
                oppositeSeatNumber = N + 1;
                seatType = 'W';
                break;
            case 6:
                oppositeSeatNumber = N - 5;
                seatType = 'W';
                break;
            case 7:
                oppositeSeatNumber = N - 3;
                seatType = 'M';
                break;
            case 8:
                oppositeSeatNumber = N - 1;
                seatType = 'A';
                break;
            case 9:
                oppositeSeatNumber = N - 7;
                seatType = 'A';
                break;
            case 10:
                oppositeSeatNumber = N - 9;
                seatType = 'M';
                break;
            case 11:
                oppositeSeatNumber = N - 11;
                seatType = 'W';
                break;
            default:
                oppositeSeatNumber = 0;
                seatType = ' ';
                break;
        }
        Console.WriteLine($"{oppositeSeatNumber} {seatType}");
    }
}
