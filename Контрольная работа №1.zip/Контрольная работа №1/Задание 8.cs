﻿using System;

class Program8
{
    static void Main8()
    {
        string[] firstLine = Console.ReadLine().Split(' ');
        int t = int.Parse(firstLine[0]);
        int v = int.Parse(firstLine[1]);
        string[] secondLine = Console.ReadLine().Split(' ');
        int[] volumes = new int[t];

        for (int i = 0; i < t; i++)
        {
            volumes[i] = int.Parse(secondLine[i]);
        }
        int totalTrucks = 0;
        for (int i = 0; i < t; i++)
        {
            int currentVolume = volumes[i];
            totalTrucks += currentVolume / v;
            if (currentVolume % v > 0)
            {
                totalTrucks++;
            }
        }
        if (volumes[0] > 0)
        {
            totalTrucks++;
        }
        Console.WriteLine(totalTrucks);
    }
}