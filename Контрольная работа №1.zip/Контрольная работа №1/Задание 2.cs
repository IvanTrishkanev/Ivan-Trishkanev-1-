﻿using System;

class Program2
{
    static void Main2(string[] args)
    {
        var input = Console.ReadLine().Split();
        int A = int.Parse(input[0]);
        int B = int.Parse(input[1]);
        int countPositiveOh = 0;
        for (int X = A; X <= B; X++)
        {
            string octalX = Convert.ToString(X, 8);
            int length = octalX.Length;
            int penultimateDigit = octalX[length - 2] - '0';
            int lastDigit = octalX[length - 1] - '0';
            int newPenultimate = (penultimateDigit < 7) ? penultimateDigit + 1 : 0;
            int newLastDigit;

            if (penultimateDigit == 7)
            {
                newLastDigit = (lastDigit % 2 == 0) ? lastDigit + 1 : lastDigit - 1;
            }
            else
            {
                newLastDigit = lastDigit;
            }
            string modifiedOctalX = octalX.Substring(0, length - 2) + newPenultimate + newLastDigit;
            int Y = Convert.ToInt32(modifiedOctalX, 8);
            int Oh = X - Y;
            if (Oh > 0)
            {
                countPositiveOh++;
            }
        }
        Console.WriteLine(countPositiveOh);
    }
}