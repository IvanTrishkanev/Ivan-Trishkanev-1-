﻿using System;

class Program9
{
    static void Main9()
    {
        string[] firstLine = Console.ReadLine().Split(' ');
        int t = int.Parse(firstLine[0]);
        int v = int.Parse(firstLine[1]);

        string[] secondLine = Console.ReadLine().Split(' ');
        int[] volumes = new int[t];
        for (int i = 0; i < t; i++)
        {
            volumes[i] = int.Parse(secondLine[i]);
        }

        int totalTrucks = 0;

        for (int i = 0; i < t; i++)
        {
            int volume = volumes[i];

            if (i == 0)
            {
                if (volume > v / 2)
                {
                    volume -= v / 2;
                    totalTrucks += 1;
                }
                else
                {
                    totalTrucks += 1;
                    continue;
                }
            }
            if (volume > 0)
            {
                totalTrucks += (volume + v - 1) / v;
            }
        }
        Console.WriteLine(totalTrucks);
    }
}