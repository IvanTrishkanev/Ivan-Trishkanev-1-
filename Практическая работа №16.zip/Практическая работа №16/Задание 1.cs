﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

[Serializable]
public class Student
{
    public string Name { get; set; }
    public int[] Grades { get; set; }

    public double AverageGrade
    {
        get { return Grades.Length > 0 ? (double)Grades.Sum() / Grades.Length : 0; }
    }
}

public class Program1
{
    public static void Main(string[] args)
    {
        string filePath = "students.html";

        List<Student> students = DeserializeStudents(filePath);
        DisplayMenu(students);
    }

    public static List<Student> DeserializeStudents(string filePath)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(List<Student>));
        using (FileStream fs = new FileStream(filePath, FileMode.Open))
        {
            return (List<Student>)serializer.Deserialize(fs);
        }
    }   

    public static void DisplayMenu(List<Student> students)
    {
        while (true)
        {
            Console.WriteLine("\nВыберите команду:");
            Console.WriteLine("1. Показать самого лучшего ученика");
            Console.WriteLine("2. Показать самого худшего ученика");
            Console.WriteLine("3. Показать все списки учеников");
            Console.WriteLine("4. Показать учеников со средним баллом выше заданного");
            Console.WriteLine("5. Выйти");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    ShowBestStudent(students);
                    break;
                case "2":
                    ShowWorstStudent(students);
                    break;
                case "3":
                    ShowAllStudents(students);
                    break;
                case "4":
                    ShowAboveAverageStudents(students);
                    break;
                case "5":
                    return;
                default:
                    Console.WriteLine("Неправильный выбор. Пожалуйста, попробуйте снова.");
                    break;
            }
        }
    }

    public static void ShowBestStudent(List<Student> students)
    {
        var bestStudent = students.OrderByDescending(s => s.AverageGrade).FirstOrDefault();
        if (bestStudent != null)
        {
            Console.WriteLine($"Лучший ученик: {bestStudent.Name}, Средний балл: {bestStudent.AverageGrade:F2}");
        }
        else
        {
            Console.WriteLine("Список студентов пуст.");
        }
    }

    public static void ShowWorstStudent(List<Student> students)
    {
        var worstStudent = students.OrderBy(s => s.AverageGrade).FirstOrDefault();
        if (worstStudent != null)
        {
            Console.WriteLine($"Худший ученик: {worstStudent.Name}, Средний балл: {worstStudent.AverageGrade:F2}");
        }
        else
        {
            Console.WriteLine("Список студентов пуст.");
        }
    }

    public static void ShowAllStudents(List<Student> students)
    {
        Console.WriteLine("\nСписок всех студентов:");
        foreach (var student in students)
        {
            Console.WriteLine($"{student.Name}, Средний балл: {student.AverageGrade:F2}");
        }
    }

    public static void ShowAboveAverageStudents(List<Student> students)
    {
        Console.Write("Введите средний балл: ");
        if (double.TryParse(Console.ReadLine(), out double average))
        {
            var aboveAverageStudents = students.Where(s => s.AverageGrade > average).ToList();

            if (aboveAverageStudents.Count > 0)
            {
                Console.WriteLine($"\nСтуденты со средним баллом выше {average:F2}:");
                foreach (var student in aboveAverageStudents)
                {
                    Console.WriteLine($"{student.Name}, Средний балл: {student.AverageGrade:F2}");
                }
            }
            else
            {
                Console.WriteLine("Нет студентов со средним баллом выше заданного.");
            }
        }
        else
        {
            Console.WriteLine("Некорректный ввод. Попробуйте снова.");
        }
    }
}